Select   r.ControlNumber "R_ControlNum",o.ControlNumber"O_ControlNum" ,
					o.ExternalBillNumber "O_ExternalBillNum" , br.LZDCN "R_LZDCN", bo.lzdcn "O_LZDCN" into Test_4
				From DBA.[dbo].[7778-NCOperators_HistoryHeader_20241001-20241231_PRD1] O with (nolock) 
				join DBA.[dbo].[7778-NCOperators_HistoryHeader_20241001-20241231_PRD1] r with (nolock) on o.ControlNumber = r.OriginalControlNumber
				jOIN SAZENPRODLZ..LZBill br
				on br.Docctrlid = r.ExternalBillNumber and br.CarrierseqNew = r.OfficeID + r.ControlNumber AND r.IsReconsideration = 'Y'
				jOIN SAZENPRODLZ..LZBill bo
				on  bo.Docctrlid = o.ExternalBillNumber and bo.CarrierseqNew = o.OfficeID + r.OriginalControlNumber + '-01' AND o.IsReconsideration <> 'Y'
				where br.lzbatchnumber  = '1145854' 
				order by 1

select LZDCN,CarrierSeqNew,LZCarrierSeqNew,DocCtrlID,* from SAZENPRODLZ..LZBill  where lzbatchnumber  = '1145854' 

select ControlNumber,OriginalControlNumber,ExternalBillNumber,* From DBA.[dbo].[7778-NCOperators_HistoryHeader_20241001-20241231_PRD1] where IsReconsideration = 'Y'
				


				select * from Test_2




select OriginalControlNumber,ExternalBillNumber,* from DBA.[dbo].[7778-NCOperators_HistoryHeader_20241001-20241231_PRD1] where IsReconsideration = 'Y'

				select LZDCN,* from SAZENPRODLZ..LZBILL where lzbatchnumber  = '1145854' 

select IsReconsideration,OriginalControlNumber,* from DBA.[dbo].[7778-NCOperators_HistoryHeader_thru20240930_PRD] where ExternalClaimNumber = '4A2211SWHJL00019M'


select IsReconsideration,OriginalControlNumber,* from DBA.[dbo].[7778-NCOperators_HistoryHeader_thru20240930_PRD] where ControlNumber= 	9910146		

select Charges,Allowance,OriginalControlNumber,* from  DBA.[dbo].[7780-GAOperators_HistoryHeader_thru20240930_PRD] where ISreconsideration = 'Y'

77809910000
77809910142
778014168-01


Select distinct  r.ControlNumber "R_ControlNum",o.ControlNumber"O_ControlNum" ,
					o.ExternalBillNumber "O_ExternalBillNum" , br.LZDCN "R_LZDCN", bo.lzdcn "O_LZDCN"-- into #tempPy
				From DBA.[dbo].[7779-SCOperators_HistoryHeader_thru20240930_PRD] O with (nolock) 
				join DBA.[dbo].[7779-SCOperators_HistoryHeader_20241001-20241231_PRD1] r with (nolock) on o.ControlNumber = r.OriginalControlNumber
				jOIN SAZENPRODLZ..LZBill br
				on br.Docctrlid = r.ExternalBillNumber and br.CarrierseqNew = r.OfficeID + r.ControlNumber AND r.IsReconsideration = 'Y'
				jOIN SAZENPRODLZ..LZBill bo
				on  bo.Docctrlid = o.ExternalBillNumber and bo.CarrierseqNew = o.OfficeID + r.OriginalControlNumber + '-01' AND o.IsReconsideration <> 'Y'
				where br.lzbatchnumber  = '1146029'
				order by 1 




				Select distinct  r.ControlNumber "R_ControlNum",o.ControlNumber"O_ControlNum" ,
					o.ExternalBillNumber "O_ExternalBillNum" , br.LZDCN "R_LZDCN", bo.lzdcn "O_LZDCN" into #tempPP
				From DBA.[dbo].[7779-SCOperators_HistoryHeader_thru20240930_PRD] O with (nolock) 
				join DBA.[dbo].[7779-SCOperators_HistoryHeader_thru20240930_PRD] r with (nolock) on o.ControlNumber = r.OriginalControlNumber
				jOIN SAZENPRODLZ..LZBill br
				on br.Docctrlid = r.ExternalBillNumber and br.CarrierseqNew = r.OfficeID + r.ControlNumber AND r.IsReconsideration = 'Y'
				jOIN SAZENPRODLZ..LZBill bo
				on  bo.Docctrlid = o.ExternalBillNumber and bo.CarrierseqNew = o.OfficeID + r.OriginalControlNumber + '-01' AND o.IsReconsideration <> 'Y'
				where br.lzbatchnumber  = '1145125'
				order by 1


				select 

select  Isreconsideration,controlNumber,OriginalControlNumber,ExternalBillNumber,* from [7779-SCOperators_HistoryHeader_thru20240930_PRD]  --where IsReconsideration = 'Y'
where ControlNumber  In  ('13256',
'13450') 

('10190','10502','10609','11152',
'11027','10502','11354','11111')

777913256-01


13256
13450



select  Isreconsideration,controlNumber,OriginalControlNumber,ExternalBillNumber,* from [7779-SCOperators_HistoryHeader_thru20240930_PRD] --where ControlNumber = 10137



where ISreconsideration = 'Y'


select * from SAZENPROD..EDIbatchlog where batchnumber  = '1146029'
		
select LZDCN,CarrierSeqNew,LZCarrierSeqNew,DocCtrlID,* from SAZENPRODLZ..LZBill where LZDCN = '777913256-01'  --where lzbatchnumber  = '1146029'  and LZDCN = '777913256' order by 1



select Isreconsideration,controlNumber,OriginalControlNumber,ExternalBillNumber,*  From DBA.[dbo].[7779-SCOperators_HistoryHeader_20241001-20241231_PRD1] 
where ISreconsideration = 'Y'
									
select Isreconsideration,controlNumber,OriginalControlNumber,ExternalBillNumber,*  From DBA.[dbo].[7779-SCOperators_HistoryHeader_20241001-20241231_PRD1] 
where OriginalControlNumber IN  ('13450')
77799910101

,'13450','12815','13604','12149','13041','13604',
'13472','13418','12149','12815','13780','12815')



