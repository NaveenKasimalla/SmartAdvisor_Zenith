

	Declare @SADatabaseName varchar(50)
	Declare @ProviderSubset varchar(5)
	Declare @SiteCode varchar(5)

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SET @SADatabaseName = 'SAZENPROD'
	SET @ProviderSubSet = 'ZNPV'
	SET @SiteCode = '@@@'
	
    -- Insert statements for procedure here
	Declare @BatchNumber bigint
	exec SAZENPROD.dbo.USP_GenerateEDIBatchNumber 1, @BatchNumber OUTPUT	
	Select @BatchNumber
	
	Declare @SqlStr nvarchar(max)
	Declare @SqlParam nvarchar(max)
	
		BEGIN TRAN TProv
	BEGIN TRY
	
		---- Query used to fetch data from text file received
		
		/* Insert data into temp table with bill information */
		select distinct
				ExternalProviderNumber As ProviderID,
				ProviderFirstname As ProviderFirstName,
				ProviderMiddlename As ProviderMiddleName,
				ProviderLastname As ProviderLastName,
				ProviderSuffix As ProviderSuffix,
				ProviderPracticeName1 As ProviderPracticeName1,
				ProviderPracticeName2 As ProviderPracticeName2,
				ProviderPracticeAddress1 As ProviderPracticeAddress1,
				ProviderPracticeAddress1 As ProviderPracticeAddress2,--changed
				ProviderPracticeCity As ProviderPracticeCity,
				ProviderPracticeState As ProviderPracticeState,
				replace(ProviderPracticeZipcode,'-','')  As ProviderPracticeZip,
				ProviderMailingName1 As ProviderMailingName1,
				ProviderMailingName2 As ProviderMailingName2,
				ProviderMailingAddress1 As ProviderMailingAddress1,
				ProviderMailingAddress1 As ProviderMailingAddress2,
				ProviderMailingCity As ProviderMailingCity,
				ProviderMailingState As ProviderMailingState,
				replace(ProviderMailingZipcode,'-','') As ProviderMailingZip,
				replace(ProviderTaxID,'-','') As ProviderTaxID,
				BillProviderType As BillProviderType,
				ActiveProvider as  ActiveProvider,
				0 As ProviderSeq
				into #HistoryProviders
				--select *
				from DBA.[dbo].[7779-SCOperators_HistoryHeader_20241001-20241231_PRD1] (nolock)	
				where RecordType = 'H'-- and ExternalProviderNumber = '752014528-0003'  

				--select 'HR-' + ExternalProviderNumber As ProviderID, * from DBA.[dbo].[ClearPath_HistoryHeader_20210401-20240401] where 
				--ExternalProviderNumber = '65833'

				---select * from #HistoryProviders

				--Drop table #HistoryProviders

				

Print 'A'

				
		--/* Search SA DB and update temp table with provider seq based on TIN, add1, City, State and Zip from history data */		
		--	SET @SqlStr = 'update vp set 
		--		ProviderSeq = ISNULL(p.ProviderSeq,0) 
		--		--ExternalID = p.ExternalID
		--	FROM #HistoryProviders vp (nolock)
		--		  inner join ' + @SADatabaseName + '.dbo.provider p (nolock)
		--				on p.ExternalID = vp.ProviderID
		--	WHERE p.ProviderSubSet = @ProviderSubSet'
			
		--	SET @SqlParam = N'@ProviderSubSet varchar(10)'
								
		--	Exec dbo.sp_ExecuteSQL @SqlStr, @SqlParam, @ProviderSubSet

		--	Print 'B'

		--/* Search SA DB and update temp table with provider seq based on TIN, add1, City, State and Zip from history data */		
			--SET @SqlStr = 'update vp set 
			--	ProviderSeq = ISNULL(p.ProviderSeq,0) 
			--	--ExternalID = p.ExternalID
			--from #HistoryProviders vp (nolock)
			--	  inner join ' + @SADatabaseName + '.dbo.provider p (nolock)
			--			on p.TIN = substring(vp.ProviderTaxID,1,9) and p.Name = substring(VP.ProviderLastName,1,50)
			--	  inner join ' + @SADatabaseName + '.dbo.ProviderAddress pa (nolock)
			--			on pa.Address1 = substring(vp.ProviderMailingAddress1,1,30)
			--				  and p.BillingAddressSeq = pa.ProviderAddressSeq
			--				  and p.ProviderSubSet = pa.ProviderSubSet
			--				  and pa.city = substring(vp.ProviderMailingCity,1,30)
			--				  and pa.state = substring(vp.ProviderMailingState,1,2)
			--				  and pa.zip = substring(vp.ProviderMailingZip,1,9)
			--				  and pa.RecType = ''P''
			--				  where p.ProviderSubSet = @ProviderSubSet'
			
			--SET @SqlParam = N'@ProviderSubSet varchar(10)'
								
			--Exec dbo.sp_ExecuteSQL @SqlStr, @SqlParam, @ProviderSubSet


		/*Insert missing provider into LZ with status as inactive*/

		INSERT INTO SAZENPRODLZ..LZProvider
			(LZRecType,LZBatchnumber,ProviderSubSet,TIN,ExternalID,Name,FirstName,
			MiddleName,LastName,Suffix,CreateUserID,CreateDate,ModUserID,ModDate,
			ExportDate,SsnTinIndicator,PmtDays,AuthBeginDate,AuthEndDate,LZAddress1P,LZAddress2P,LZCityP,
			LZStateP,LZZipP,LZAddress1B,LZAddress2B,LZCityB,LZStateB,
			LZZipB,LZTIN,LZExternalID,LZName,LZFirstName,LZMiddleName,LZLastName,LZSuffix,
			Address1P,Address2P,CityP,StateP,ZipP,
			Address1B,Address2B,
			CityB,StateB,
			ZipB,
			LZRebatchSeq,EntityType,Status,
			LZProvType, ProvType, Specialty1,LZSpecialty1)
		SELECT 
			Distinct 'PV',@BatchNumber,@ProviderSubSet,SubString(ProviderTaxID,1,9),ProviderID,ProviderLastName,SubString(ProviderFirstName,1,25),
			SubString(ProviderMiddleName,1,25),SubString(ProviderLastName,1,35),ProviderSuffix,'X5',getdate(),'X5',getdate(),
			'01/01/1900',NULL,0,'01/01/1900','01/01/1900',ProviderPracticeAddress1,ProviderPracticeAddress2,ProviderPracticeCity,
			ProviderPracticeState,ProviderPracticeZip,ProviderMailingAddress1,ProviderMailingAddress2,ProviderMailingCity,ProviderMailingState,
			ProviderMailingZip,ProviderTaxID,ProviderID,ProviderLastName,ProviderFirstName,ProviderMiddleName,ProviderLastName,ProviderSuffix,				
			SubString(ProviderMailingAddress1,1,30),SubString(ProviderPracticeAddress2,1,30),SubString(ProviderMailingCity,1,30),ProviderMailingState,Substring(ProviderMailingZip,1,9) as ProviderMailingZip,
			SubString(ProviderMailingAddress1,1,30),SubString(ProviderMailingAddress2,1,30),
			SubString(ProviderMailingCity,1,30)
			,ProviderMailingState
			,Replace(ProviderMailingZip,'-','') as ProviderMailingZip,
			0,
			2,
			'I',
				case When BillProviderType = 'NP' 	THEN	'NP'
When BillProviderType =  'PA'	THEN	'PA'
When BillProviderType =  'PHY'	THEN	'DR'
When BillProviderType =  'HO'	THEN	'HO'
When BillProviderType =  'RPT'	THEN	'DR'
When BillProviderType =  'DO'	THEN	'DO'
When BillProviderType =  'OT'	THEN	'OT'
When BillProviderType =  'ICC'	THEN	'DR'
When BillProviderType =  'PH'	THEN	'PH'
When BillProviderType =  'HH'	THEN	'DR'
When BillProviderType =  'SC'	THEN	'SC'
When BillProviderType =  'CRNA' THEN	'DR'
When BillProviderType =  'DMS'	THEN	'DR'
When BillProviderType =  'PS'	THEN	'PS' end as LZProvType,

case When BillProviderType = 'NP' 	THEN	'NP'
When BillProviderType =  'PA'	THEN	'PA'
When BillProviderType =  'PHY'	THEN	'DR'
When BillProviderType =  'HO'	THEN	'HO'
When BillProviderType =  'RPT'	THEN	'DR'
When BillProviderType =  'DO'	THEN	'DO'
When BillProviderType =  'OT'	THEN	'OT'
When BillProviderType =  'ICC'	THEN	'DR'
When BillProviderType =  'PH'	THEN	'PH'
When BillProviderType =  'HH'	THEN	'DR'
When BillProviderType =  'SC'	THEN	'SC'
When BillProviderType =  'CRNA' THEN	'DR'
When BillProviderType =  'DMS'	THEN	'DR'
When BillProviderType =  'PS'	THEN	'PS' end as ProvType,




				'' as Specialty1,

      '' as LZSpecialty1
 
		From #HistoryProviders
		Where ProviderSeq = 0

		Print 'C'

	
		----Insert into LZHeaderTrailer with type as 'FH'
		insert into SAZENPRODLZ..LZHeaderTrailer(LZBatchNumber, RecordType, BranchOfficeCode)
		values(@BatchNumber,'FH',@SiteCode)

		--- Insert into LZHeaderTrailer with type as 'FT'
		insert into SAZENPRODLZ..LZHeaderTrailer(LZBatchNumber, RecordType, BranchOfficeCode)
		values(@BatchNumber,'FT',@SiteCode)
		
		----Insert into the EDIBatchlog table
		SET @SqlStr = 'insert into ' + @SADatabaseName + '.dbo.edibatchlog
			(BatchNumber,SiteCode,EDIPortType,EDIMapToolID,EDIBatchDate,UserID, FromDate, 
				ToDate,EDIControlSeq,LzRebatchSeq,Preprocess,BatchManagerSeq,FileSpec)
			values(@BatchNumber,''ZZZ'',''I'',''3'',getdate(),''X5'',''01/01/1998'',''12/31/2100'',3,0,0,83,''Prov_SCO_PRD'')'

		SET @SqlParam = N'@BatchNumber varchar(10)'
								
		Exec dbo.sp_ExecuteSQL @SqlStr, @SqlParam, @BatchNumber

		Print 'D'
			
		drop table #HistoryProviders
	COMMIT TRAN
END TRY
	BEGIN CATCH
		print error_message() 
			ROLLBACK TRAN
	END CATCH

GO






