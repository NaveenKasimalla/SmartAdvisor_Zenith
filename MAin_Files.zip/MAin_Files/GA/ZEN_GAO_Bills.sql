--select claimSyssubset, * from SAZENPROD..Client where ClaimSysSubSet = 'NOSZ'  and Jurisdiction = 'NC' 

--GOSZ, SOSZ and NOSZ 

	-- Add the parameters for the stored procedure here
	Declare @SADatabaseName varchar(500) --DB name
	Declare @ClaimSysSubSet varchar(40)
	Declare @ProviderSubSet varchar(40)
	Declare @SiteCode varchar(5)

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	Declare @SqlStr nvarchar(MAX)
	Declare @SqlParam nvarchar(MAX)
	Declare @BatchNumber as bigint

    
	SET @SADatabaseName = 'SAZENPROD'
	SET @ClaimSysSubSet = 'GOSZ'
	SET @ProviderSubSet = 'ZNPV'
	SET @SiteCode = '@@@'

	EXEC SAZENPROD.dbo.USP_GenerateEDIBatchNumber 1, @BatchNumber OUTPUT	 --Get Batchnumber
	Select @BatchNumber

BEGIN TRAN TBill
BEGIN TRY
	
		/* Insert data into temp table with bill information */
		
		
			select 			 
				RecordType As RecordType,
				ClaimJurisdictionState As JurisdictionState,
				ClaimantFirstName As ClaimantFirstName,
				ClaimantMiddleName As ClaimantMiddleName,
				ClaimantLastName As ClaimantLastName,
				ClaimantState As ClaimState,
				SocialSecurityNumber As SocialSecurityNumber,				
				DateOfInjury As DateOfInjury,
				Externalclaimnumber  As ClaimNumber,
				ClaimNumberSuffix As ClaimNumberSuffix,
				Charges As Charges,
				Allowance As Allowance,
				 ExternalProviderNumber As ProviderID,
				ProviderFirstname As ProviderFirstName,
				ProviderMiddlename As ProviderMiddleName,
				ProviderLastname As ProviderLastName,
				ProviderSuffix As ProviderSuffix,
				ProviderPracticeName1 As ProviderPracticeName1,
				ProviderPracticeName2 As ProviderPracticeName2,
				case when isnull(ProviderPracticeAddress1, '') ='' then ProviderMailingAddress1 else ProviderPracticeAddress1 end As ProviderPracticeAddress1,
				case when isnull(ProviderPracticeAddress1, '') ='' then ProviderMailingAddress2 else ProviderPracticeAddress2 end As ProviderPracticeAddress2,
				case when isnull(ProviderPracticeAddress1, '') ='' then ProviderMailingCity else ProviderPracticeCity end As ProviderPracticeCity,
				case when isnull(ProviderPracticeAddress1, '') ='' then Upper(ProviderMailingState) else Upper(ProviderPracticeState) end As ProviderPracticeState,
				case when isnull(ProviderPracticeAddress1, '') ='' then replace(ProviderMailingZipcode,'-','') else replace(ProviderPracticeZipcode,'-','') end As ProviderPracticeZip,
				ProviderMailingName1 As ProviderMailingName1,
				ProviderMailingName2 As ProviderMailingName2,
				ProviderMailingAddress1 As ProviderMailingAddress1,
				ProviderMailingAddress2 As ProviderMailingAddress2,
				ProviderMailingCity As ProviderMailingCity,
				ProviderMailingState As ProviderMailingState,
				ProviderMailingZipcode As ProviderMailingZip,
				replace(ProviderTaxID,'-','') As ProviderTaxID,
				BillProviderType As BillProviderType,
			    ICDX1 As ICDDiagnosisCode1,
				ICDX2 As ICDDiagnosisCode2,
				ICDX3 As ICDDiagnosisCode3,
				ICDX4 As ICDDiagnosisCode4,
				ICDX5 As ICDDiagnosisCode5,
				ICDX6 As ICDDiagnosisCode6,
				ICDX7 As ICDDiagnosisCode7,
				ICDX8 As ICDDiagnosisCode8,
				ICD10X1 As ICD10DiagnosisCode1,
				ICD10X2 As ICD10DiagnosisCode2,
				ICD10X3 As ICD10DiagnosisCode3,
				ICD10X4 As ICD10DiagnosisCode4,
				ICD10X5 As ICD10DiagnosisCode5,
				ICD10X6 As ICD10DiagnosisCode6,
				ICD10X7 As ICD10DiagnosisCode7,
				ICD10X8 As ICD10DiagnosisCode8,

				TypeOfBill As TypeOfBill,
				ServiceFromDate As ServiceFromDate,
				ServiceThroughDate As ServiceThroughDate,
				EmployerName As EmployerName,
				EmployerNumber As EmployerNumber,
				EmployerPolicyNumber As EmployerPolicyNumber,
				EmployerAddress1 As EmployerAddress1,
				EmployerAddress2 As EmployerAddress2,
				EmployerCity As EmployerCity,
				Upper(EmployerState) As EmployerState,
				replace(EmployerZipcode,'-','') As EmployerZip,
				IsReconsideration As IsReconsideration,
				@SiteCode As SiteCode,			
				BillReviewProcessDate As BillReviewProcessDate,
				BillReviewReceivedDate As BillReviewReceivedDate,
				--HospitalAdmissionDate As AdmitDate,
				HospitalDischargeDate As DischargeDate,
				UB92TypeOfBill As UB92TypeOfBill,
				ProviderPatientAccount As ProviderPatientAccount,
				ExternalBillNumber As ExternalBillNumber,
				OfficeID As HistoryClientNumber,
				ControlNumber As ControlNumber,
				Replace(ProviderNPINumber,'','') As ProviderBillingNPI,
				Replace(PracticeNPINumber,'','') As ProvFacilityNPI,
				InjuryReportedDate as AdmitDate,
				0 As ProviderSeq,
				 ExternalProviderNumber As ExternalID,-- cast('' as varchar(30)) As ExternalID,
				0 As LineSeq
				Into  #HistoryBills --Drop table #PALCCHistoryBills
				--select OriginalControlNumber,IsReconsideration,TypeOFBill,charges,allowance,*
				from DBA.[dbo].[7780-GAOperators_HistoryHeader_thru20240930_PRD] BH with (nolock)
				where RecordType = 'H' --and IsReconsideration  in ('Y')--- Externalclaimnumber = 'GAOS-01836125'--and claimJurisdictionState not in ('GA')-- and ClaimantFirstName = 'MARIA' and ClaimantLastName = 'TUAZON' --and ExternalBillNumber = '358' and charges = '0.00' and allowance ='0.00'
				Print 'A'

				


				--select Charges,Allowance,* from DBA.[dbo].[SpringISD_HistoryHeader_20210501-20240501] where ExternalBillNumber in ('358','345','46')

				--select ExternalBillNumber,Charges,Allowance,* from DBA.[dbo].[SpringISD_HistoryHeader_20210501-20240501] where Charges ='0.00' and Allowance = '0.00'
			

				--select ProviderNPINumber,PracticeNPINumber,* from DBA.[dbo].[ClearPath_HistoryHeader_20210401-20240401]
				
----------------------------------------------------------------------------------------------------------------------------------------------------------
		
--			/* Insert data into temp table with line information */
			select  
				BD.RecordType As RecordType,
				BD.DateOfService As DateofService,
				BD.ServiceCode As ServiceCode,
				--BD.ServiceCode2 as ServiceCode2,--added
	--	 bd.ServiceCode as  ProcBilled,
	--		bd.ServiceCode as  LZProcBilled ,
	--bd.ServiceCode as  ProcCode ,
	--	 bd.ServiceCode	as LZProcCode  ,
				BD.Modifier1 As Modifier0,
				BD.Modifier2 As Modifier1,
				BD.Modifier3 As Modifier2,
				BD.Modifier4 As Modifier3,
				BD.Quantity As Quantity,
				BD.Charges As Charges,
				BD.Allowance As Allowance, ----- Implied Decimal
				BD.PlaceOfService As PlaceOfService,
				BD.TypeOfService as TypeOfService,
				BD.OriginalServiceCode as OriginalServiceCode,
				BD.TaxCharges as TaxCharges,
				BD.TaxAllowance as TaxAllowance,
				BD.BRReduction as BillReviewReduction,
				BD.PPOReduction as PPOReduction,
				BD.OtherReduction as OtherReduction,
				BD.NegotiatedReduction as NegotiatedReduction,
				BD.UtilizationReviewReduction as UtilizationReviewReduction,
				BD.FeeScheduleReduction as FeeScheduleReduction,
				BD.UCRReduction as UCRReduction,
				BD.OSRReduction as OSRReduction,
				BD.BRRulesReduction as BRRulesReduction,
				BD.NurseReduction as NurseReduction,
				BD.ClientSpecificReduction as ClientSpecificReduction,
				BD.AdjusterReduction as AdjusterReduction,
				BD.ApportionmentReduction as AppointmentReduction,
				BD.TaxReduction as TaxReduction,
				BD.SurchargeReduction as SurchargeReduction,
				BD.FeeScheduleAllowance as FeeScheduleAllowance,--added
				BD.UCRAllowance as UCRAllowance,--added
				Bd.PPOAllowance as PPOAllowance,--added
				BD.OSRAllowance as OSRAllowance,--added
				BD.BRRulesAllowance as BRRulesAllowance,--added
				BD.DuplicateReduction as DuplicateReduction,
				BD.ReasonCodes as ReasonCodes,
				BD.ExternalBillNumber as ExternalBillNumber,
				@SiteCode As SiteCode,
				--BD.ClientNumber As ClientNumber,
				BD.OfficeID As HistoryClientNumber,
				BD.ControlNumber As ControlNumber,
				BD.ServiceLineNumber As LineNumber,

				0 As LineSeq
			Into  #HistoryLines  --Drop table #PALCCHistoryLines
				--select ExternalBillNumber as DocCtrlId,Servicecode as Proccode,Charges,Allowance, *
				from DBA.DBO.[7780-GAOperators_HistoryDetail_thru20240930_PRD] BD with (nolock)		
				where BD.RecordType = 'D'-- and  ExternalBillNumber = '358' and controlNumber = '9910185'

				Print 'B'

			

			--select ServiceCode ,* from 	 DBA.[dbo].[ClearPath_HistoryDetail_20210401-20240401]

			--select ExternalBillNumber,Charges,Allowance,* from DBA.[dbo].[SpringISD_HistoryDetail_20210501-20240501] where Charges ='0.00' and Allowance = '0.00'

			
	
		----------------------------------------------------------------------------------------------------------------

			SET @SqlStr = 'update vp set 
				vp.ProviderSeq = p.ProviderSeq
				--ExternalID = Left(p.ExternalID,30)
			from #HistoryBills vp (nolock)
				  inner join ' + @SADatabaseName + '.dbo.provider p (nolock)
						on p.TIN = substring(vp.ProviderTaxID,1,9) 
						and p.ExternalID = substring(VP.ExternalID,1,50)
			where p.ProviderSubSet = ''' + @ProviderSubSet + ''''
			Exec (@SqlStr)
					
					Print 'C'

		---Declar and create Temp Table for LZBIll
		CREATE TABLE #TempBill 
		(
			LZBatchNumber bigint,
			LZRecType char(3),
			LZBillStatus int,
			ClientCode char(4),
			ClaimSeq bigint,
			ClaimSysSubSet char(4),
			ProviderSeq bigint,
			ProviderSubSet char(4),
			DOSFirst DateTime,
			CarrierSeqNew nvarchar(30),
			DOSLast DateTime,
			POS nvarchar(2),
			LZPOS nvarchar(4),
			ProvType nvarchar(3),
			LZProvType nvarchar(6),
			ProvSpecialty1 varchar(8),
			LZProvSpecialty1 varchar(16),
			ProvZip nvarchar(9),---changed
			ProvState char(2),
			CreateUserID char(2),
			ModUserID char(2),
			TotalCharge money,
			TOS nvarchar(4),
			TOB nvarchar(4),
			LZTOS varchar(4),
			LZTOB varchar(4),
			SubProductCode char(1),
			RcvdDate Datetime,
			RcvdBRDate Datetime,
			DOI datetime,
			SiteCode char(3),
			LZSiteCode char(6),			
			LZICDDiagCode1 nvarchar(20),
			LZICDDiagCode2 nvarchar(20),
			LZICDDiagCode3 nvarchar(20),
			LZICDDiagCode4 nvarchar(20),
			LZICDDiagCode5 nvarchar(20),
			LZICDDiagCode6 nvarchar(20),
			LZICDDiagCode7 nvarchar(20),
			LZICDDiagCode8 nvarchar(20),
			TotalAllow Money,
			LZClaimNum nvarchar(50),
			LZProvState char(2),
			LZProvZip nvarchar(19),
			LZDCN nvarchar(50),
			LZCarrierSeqNew nvarchar(50),
			LZClientCode char(4),
			ICDDiagCode1 nvarchar(8),
			ICDDiagCode2 nvarchar(8),
			ICDDiagCode3 nvarchar(8),
			ICDDiagCode4 nvarchar(8),
			ICDDiagCode5 nvarchar(8),
			ICDDiagCode6 nvarchar(8),
			ICDDiagCode7 nvarchar(8),
			ICDDiagCode8 nvarchar(8),
		
			LZProvTin nvarchar(50),
			PaidDate datetime,
			PaidAmount money,
			FacilityTOB nvarchar(10),
			AlreadyRepriced char(1),
			ReviewDate datetime,
			PostDate datetime,
			LZExternalProviderID varchar(30),
			AdmitDate datetime,
			DischargeDate datetime,
			UB92TOB varchar(60),
			LZUB92TOB varchar(50),
			ProvBillingNPI varchar(10),
			LZProvBillingNPI varchar(10),
			ProvFacilityNPI varchar(10),
			LZProvFacilityNPI varchar(10),
			ClaimState varchar(10),
			LZProvBillAddr1 varchar(50),
			LZProvBillAddr2 varchar(50),
			LZProvBillCity varchar(50),
			LZProvBillState varchar(20),
			LZProvBillZip varchar(20),
			LZProvPRAddr1 varchar(50),
			LZProvPRAddr2 varchar(50),
			LZProvPRCity varchar(50),
			LZProvPRState varchar(20),
			LZProvPRZip varchar(20),
			DocCtrlID varchar(100)
		)

		Print 'D'

		/*INSERT INTO Temp BILL from History temp table */
		insert into #TempBill
			select 
				@BatchNumber,
				'002' As LZRecType,
				99 As LZBillStatus,				
				'GOGA' as ClientCode,-----need change
				0 As ClaimSeq,
				@ClaimSysSubSet As ClaimSysSubset,
				B.ProviderSeq,
				@ProviderSubSet,
				cast(B.ServiceFromDate as datetime),
				Case When B.IsReconsideration = 'N' Then B.HistoryClientNumber + B.ControlNumber + '-01' Else B.HistoryClientNumber + B.ControlNumber End As CarrierSeqNew,
				cast(B.ServiceThroughDate as datetime),
			--	TypeofBill As POS,
			--	TypeofBill As LZPOS,				
				Case When B.TypeOfBill ='P' THEN '11'
					WHEN B.TypeOfBill = 'I' THEN '21'
					WHEN B.TypeOfBill = 'O' THEN '22'
					WHEN B.TypeOfBill = 'D'  THEN '11'
					WHEN B.TypeOfBill = 'H'  THEN '01'	
				Else '01' END As POS,				
				Case When B.TypeOfBill ='P' THEN '11'
					WHEN B.TypeOfBill = 'I' THEN '21'
					WHEN B.TypeOfBill = 'O' THEN '22'
					WHEN B.TypeOfBill = 'D'  THEN '11'
					WHEN B.TypeOfBill = 'H'  THEN '01'		
				Else '01' END As LZPOS,
				
				case  when BillProviderType = 'PHY' then  'DR'
  when  BillProviderType = 'NP ' then  'NP'
  when  BillProviderType = 'RPT' then  'DR'
  when  BillProviderType = 'PH ' then  'DR'
  when  BillProviderType = 'HO ' then  'HP'
  when  BillProviderType = 'PA ' then  'PA'
  when  BillProviderType = 'DMS' then  'DQ'
  when  BillProviderType = 'POD' then  'PO'
  when  BillProviderType = 'HH ' then  'HH'
  when  BillProviderType = 'OT ' then  'OT'
  when  BillProviderType = 'PAT' then  'LA'
  when  BillProviderType = 'AT	' then  'AT'
  when  BillProviderType = 'DO	' then  'DO'
  when  BillProviderType = 'OMP' then  'OM'
  when  BillProviderType = 'SC ' then  'AS'
  when  BillProviderType = 'APR' then  'AR'
  when  BillProviderType = 'HI ' then  'HP'
  when  BillProviderType = 'CRN' then  'CR'
  when  BillProviderType = 'ORP' then  'DQ'
  when  BillProviderType = 'PS ' then  'PS'
  when  BillProviderType = 'DG	' then  'DG'
  when  BillProviderType = 'MSC' then  'DQ'
  when  BillProviderType = 'AN	' then  'AN'
  when  BillProviderType = 'AA	' then  'AA'
  when  BillProviderType = 'ICC' then  'CL'
  when  BillProviderType = 'OPT' then  'OH'
  when  BillProviderType = 'LSA' then  'DR'
  when  BillProviderType = 'SC	' then  'AS'
  when  BillProviderType = 'MRI' then  'DG'
  when  BillProviderType = 'ATC' then  'TA'
  when  BillProviderType = 'RN	' then  'RN' end as ProvType,

case when BillProviderType = 'PHY' then  'DR'
  when  BillProviderType = 'NP ' then  'NP'
  when  BillProviderType = 'RPT' then  'DR'
  when  BillProviderType = 'PH ' then  'DR'
  when  BillProviderType = 'HO ' then  'HP'
  when  BillProviderType = 'PA ' then  'PA'
  when  BillProviderType = 'DMS' then  'DQ'
  when  BillProviderType = 'POD' then  'PO'
  when  BillProviderType = 'HH ' then  'HH'
  when  BillProviderType = 'OT ' then  'OT'
  when  BillProviderType = 'PAT' then  'LA'
  when  BillProviderType = 'AT	' then  'AT'
  when  BillProviderType = 'DO	' then  'DO'
  when  BillProviderType = 'OMP' then  'OM'
  when  BillProviderType = 'SC ' then  'AS'
  when  BillProviderType = 'APR' then  'AR'
  when  BillProviderType = 'HI ' then  'HP'
  when  BillProviderType = 'CRN' then  'CR'
  when  BillProviderType = 'ORP' then  'DQ'
  when  BillProviderType = 'PS ' then  'PS'
  when  BillProviderType = 'DG	' then  'DG'
  when  BillProviderType = 'MSC' then  'DQ'
  when  BillProviderType = 'AN	' then  'AN'
  when  BillProviderType = 'AA	' then  'AA'
  when  BillProviderType = 'ICC' then  'CL'
  when  BillProviderType = 'OPT' then  'OH'
  when  BillProviderType = 'LSA' then  'DR'
  when  BillProviderType = 'SC	' then  'AS'
  when  BillProviderType = 'MRI' then  'DG'
  when  BillProviderType = 'ATC' then  'TA'
  when  BillProviderType = 'RN	' then  'RN' end as LZProvType,




				'' as Speciality1,
				'' as LZSpecialty1,
				replace(ProviderPracticeZip,' ','') As ProvZip,
				ProviderPracticeState As ProviderState,
				'@@' As CreateUserID,
				'@@' As ModUserID,
				cast(convert(decimal(10,2),RTRIM(B.Charges)) as money) As TotalCharge,
				'' As TOS,
				Case When B.TypeOfBill ='P' THEN 'M'
					WHEN B.TypeOfBill = 'I' THEN 'I'
					WHEN B.TypeOfBill = 'O' THEN 'O'
					WHEN B.TypeOfBill = 'D'  THEN 'D'
					WHEN B.TypeOfBill = 'H'  THEN 'P'	
				Else 'P' END As TOB,
				'' As LZTOS,
				Case When B.TypeOfBill ='P' THEN 'M'
					WHEN B.TypeOfBill = 'I' THEN 'I'
					WHEN B.TypeOfBill = 'O' THEN 'O'
					WHEN B.TypeOfBill = 'D'  THEN 'D'
					WHEN B.TypeOfBill = 'H'  THEN 'P'	
				Else 'P' END As LZTOB,
				'@' As SubProductCode,
				cast(B.BillReviewReceivedDate as datetime) As RcvdDate,
				cast(B.BillReviewProcessDate as datetime) As RcvdBrDate,
				cast(B.DateOfInjury as datetime),
				@SiteCode As SiteCode,
				@SiteCode As LZSiteCode,				
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode1,'.','') else Replace(B.ICD10DiagnosisCode1,'.','') End As LZICDDiagCode1,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode2,'.','') else Replace(B.ICD10DiagnosisCode2,'.','') End As LZICDDiagCode2,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode3,'.','') else Replace(B.ICD10DiagnosisCode3,'.','') End As LZICDDiagCode3,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode4,'.','') else Replace(B.ICD10DiagnosisCode4,'.','') End As LZICDDiagCode4,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode5,'.','') else Replace(B.ICD10DiagnosisCode5,'.','') End As LZICDDiagCode5,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode6,'.','') else Replace(B.ICD10DiagnosisCode6,'.','') End As LZICDDiagCode6,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode7,'.','') else Replace(B.ICD10DiagnosisCode7,'.','') End As LZICDDiagCode7,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode8,'.','') else Replace(B.ICD10DiagnosisCode8,'.','') End As LZICDDiagCode8,
				B.Allowance As TotalAllow,
				B.ClaimNumber As LZClaimNum,
				substring(ProviderPracticeState,1,2) As LZProvState,
				replace(ProviderPracticeZip,' ','') As LZProvZip,
				Case When B.IsReconsideration = 'N' Then B.HistoryClientNumber + B.ControlNumber + '-01' Else B.HistoryClientNumber + B.ControlNumber End As LZDCN,
				Case When B.IsReconsideration = 'N' Then B.HistoryClientNumber + B.ControlNumber + '-01' Else B.HistoryClientNumber + B.ControlNumber End As LZCarrierSeqNew,				
				'GOGA'  as LZClientCode,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode1,'.','') else Replace(B.ICD10DiagnosisCode1,'.','') End As ICDDiagCode1,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode2,'.','') else Replace(B.ICD10DiagnosisCode2,'.','') End As ICDDiagCode2,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode3,'.','') else Replace(B.ICD10DiagnosisCode3,'.','') End As ICDDiagCode3,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode4,'.','') else Replace(B.ICD10DiagnosisCode4,'.','') End As ICDDiagCode4,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode5,'.','') else Replace(B.ICD10DiagnosisCode5,'.','') End As ICDDiagCode5,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode6,'.','') else Replace(B.ICD10DiagnosisCode6,'.','') End As ICDDiagCode6,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode7,'.','') else Replace(B.ICD10DiagnosisCode7,'.','') End As ICDDiagCode7,
				case when B.ICDDiagnosisCode1 <> '' Then Replace(B.ICDDiagnosisCode8,'.','') else Replace(B.ICD10DiagnosisCode8,'.','') End As ICDDiagCode8,
				B.ProviderTaxID As LZProvTin,
				Cast(B.BillReviewProcessDate as datetime) as PaidDate,
				cast(convert(decimal(10,2),RTRIM(B.Allowance)) as money) As PaidAmount,
				B.TypeOfBill As FacilityTOB,
				'Y' As AlreadyRepriced,
				BillReviewProcessDate As ReviewDate,
				Cast(B.BillReviewProcessDate as datetime) As PostDate,
				substring(ExternalID,1,30),
				B.AdmitDate,
				B.DischargeDate,
				Case When b.UB92TypeOfBill <> t.Code THEN
					''
				ELSE b.UB92TypeOfBill END AS UB92TOB,
				Case When b.UB92TypeOfBill <> t.Code THEN
					''
				ELSE b.UB92TypeOfBill END AS LZUB92TOB,
				Substring(B.ProviderBillingNPI,1,10) as ProvBillingNPI,
				Substring(B.ProviderBillingNPI,1,10) as LZProvBillingNPI,
				Substring(B.ProvFacilityNPI,1,10) as ProvFacilityNPI,
				Substring(B.ProvFacilityNPI ,1,10)as LZProvFacilityNPI,
				Substring(B.ClaimState,1,10) as ClaimState,
				ProviderMailingAddress1,
				ProviderMailingAddress2,
				ProviderMailingCity,
				ProviderMailingState,
				ProviderMailingZip,
				ProviderPracticeAddress1,
				ProviderPracticeAddress2,
				ProviderPracticeCity,
				ProviderPracticeState,
				ProviderPracticeZip,
				ExternalBillNumber
		from  #HistoryBills B (nolock) 
		-----INNER JOIN SAFIDPROD..CLAIM c (nolock) on B.ClaimNumber=c.ClaimID 
			LEFT OUTER JOIN SAZENPROD.dbo.tablelookup t 
				on b.UB92TypeOfBill = t.Code and tablecode = 'XX' and TypeCode = 'UT'
				--where c.claimsyssubset ='PX'	
				
				Print 'E'

				---select * from SATSBTEST.dbo.tablelookup 
				--Select 
				
	CREATE TABLE #TempLine  
		(
			LZBatchNumber bigint,
			LZRecType char(3),
			LZLineStatus int,
			ClientCode char(4),
			LineSeq int,
			DOS DateTime,
			NDCCode varchar(100),
			DOSTo datetime,
			ProcBilled varchar(30),
			LZProcBilled varchar(30),
			ProcCode varchar(30),
			LZProcCode varchar(30),
			Units money,
			Charge money,
			BRAllow money,
			PPOAllow money,
			POS varchar(10),
			Modifier0 varchar(10),
			LZModifier0 varchar(10),
			Modifier1 varchar(10),
			LZModifier1 varchar(10),
			LZDCN varchar(50),
			RevenueCode  varchar(10),
			Modifier2 varchar(10),
			LZModifier2 varchar(10),
			Modifier3 varchar(10),
			LZModifier3 varchar(10),
			ReasonCodes varchar(100),
			Reduction1	money,
			Reduction2 money,
			Reduction3 money,
			Reduction4 money,
			Reduction5 money,
			--Reduction6 money,
			LZReduction1	varchar(12),
			LZReduction2	varchar(12),
			LZReduction3	varchar(12),
			LZReduction4	varchar(12),
			LZReduction5	varchar(12),
			--LZReduction6	varchar(12),
			ReductionCode1	smallint,
			ReductionCode2	smallint,
			ReductionCode3	smallint,
			ReductionCode4	smallint,
			ReductionCode5	smallint,
			--ReductionCode6	smallint,
			LZReductionCode1	varchar(5),
			LZReductionCode2	varchar(5),
			LZReductionCode3	varchar(5),
			LZReductionCode4	varchar(5),
			LZReductionCode5	varchar(5)
		)

		Print 'F'


--INSERT Temp line table from History temp line table
		insert into #TempLine
			select
				@BatchNumber,
				'003' As RecType,
				99 as LZLineStatus,
				'GOGA' as ClientCode,
				Convert(int,l.LineNumber) As LineSeq,
				cast(l.DateofService as datetime) As DOS,				
				Case When Len(l.ServiceCode) > 6 THEN Replace(l.ServiceCode,' ' ,' ') Else '' END As NDCCode,
				--Replace(l.ServiceCode,' ' ,' ') as NDCCode,
				cast(b.ServiceFromDate as datetime) As DosTo,
				--l.ServiceCode as  l.ServiceCode,
				--l.ServiceCode as  l.ServiceCode,
				--l.ServiceCode as   l.ServiceCode,
				--l.ServiceCode as  l.ServiceCode,
				Case WHEN Len(l.ServiceCode) = 5 THEN '0'+ l.ServiceCode
					WHEN  Len(l.ServiceCode) = 4 THEN '00'+ l.ServiceCode 
				 when  Len(l.ServiceCode) > 6 then '0' + l.ServiceCode 
					WHEN  Len(l.ServiceCode) <= 3 THEN '00'+ l.ServiceCode
					Else l.ServiceCode END,
				Case WHEN Len(l.ServiceCode) = 5 THEN '0'+ l.ServiceCode 
					WHEN  Len(l.ServiceCode) = 4 THEN '00'+ l.ServiceCode 
					WHEN  Len(l.ServiceCode) > 6 THEN '0'+ l.ServiceCode 
					WHEN  Len(l.ServiceCode) <= 3 THEN '00'+ l.ServiceCode 
					Else l.ServiceCode END,
				Case WHEN Len(l.ServiceCode) = 5 THEN '0'+ l.ServiceCode 
					WHEN  Len(l.ServiceCode) = 4 THEN '00'+ l.ServiceCode 
				WHEN Len(l.ServiceCode) > 6 THEN '0'+ l.ServiceCode 
					WHEN  Len(l.ServiceCode) <= 3 THEN ''
					Else l.ServiceCode END,
				Case WHEN Len(l.ServiceCode) = 5 THEN '0'+ l.ServiceCode 
					WHEN  Len(l.ServiceCode) = 4 THEN '00'+ l.ServiceCode 
					WHEN Len(l.ServiceCode) > 6 THEN '0'+ l.ServiceCode 
					WHEN  Len(l.ServiceCode) <= 3 THEN ''
					Else l.ServiceCode END,
				cast(convert(decimal(10,2),RTRIM(l.Quantity)) as money) As Units,
				Case When cast(convert(decimal(10,2),RTRIM(l.Charges)) as money) > 0 Then
					cast(convert(decimal(10,2),RTRIM(l.Charges)) as money) 
				Else 
					cast(convert(decimal(10,2),RTRIM(l.TaxCharges)) as money)
				END As Charge,
				Case When cast(convert(decimal(10,2),RTRIM(l.Charges)) as money) > 0 THEN
					cast(convert(decimal(10,2),RTRIM(l.Charges)) as money) - cast(convert(decimal(10,2),RTRIM(l.BillReviewReduction)) as money) 
				Else cast(convert(decimal(10,2),RTRIM(l.TaxCharges)) as money) - cast(convert(decimal(10,2),RTRIM(l.TaxAllowance)) as money)  + cast(convert(decimal(10,2),RTRIM(l.BillReviewReduction)) as money) 
				END
				As BRAllow,
				Case When cast(convert(decimal(10,2),RTRIM(l.Charges)) as money) > 0 THEN
					cast(convert(decimal(10,2),RTRIM(l.Charges)) as money)  + cast(convert(decimal(10,2),RTRIM(l.BillReviewReduction)) as money) + convert(money,l.PPOReduction) 
				ELSE cast(convert(decimal(10,2),RTRIM(l.TaxCharges)) as money) - cast(convert(decimal(10,2),RTRIM(l.TaxAllowance)) as money)  + cast(convert(decimal(10,2),RTRIM(l.PPOReduction)) as money)
				END As PPOAllow,
				l.PlaceOfService As POS,
				l.Modifier0 As Modifier0,
				l.Modifier0 As LZModifier0,
				l.Modifier1 As Modifier1,
				l.Modifier1 As LZModifier1,
				Case When B.IsReconsideration = 'N' Then L.HistoryClientNumber + L.ControlNumber + '-01' Else L.HistoryClientNumber + L.ControlNumber End As LZDCN,				
				Case When len(l.ServiceCode) <=3 Then
				l.ServiceCode Else '' END As RevenueCode,
				-- Substring(l.ServiceCode,1,7)  As RevenueCode,
				--l.ServiceCode As RevenueCode,
				l.Modifier2 As Modifier2,
				l.Modifier2 As LZModifier2,
				l.Modifier3 As Modifier3,
				l.Modifier3 As LZModifier3	,
				ReasonCodes,
				Convert(money,BillReviewReduction),
				Convert(money,UtilizationReviewReduction),
				Convert(money,PPOReduction),
				Convert(money,OtherReduction) + Convert(money,l.SurchargeReduction),-- + cast(convert(decimal(10,2),RTRIM(l.TaxAllowance)) as money),
				--Convert(money,OSRReduction),
				Convert(money,l.NegotiatedReduction),
				l.BillReviewReduction,
				l.UtilizationReviewReduction,
				l.PPOReduction,	
				Cast((Convert(money,l.OtherReduction) + Convert(money,l.SurchargeReduction))  + cast(convert(decimal(10,2),RTRIM(l.TaxAllowance)) as money) as varchar),
				--OSRReduction,
				l.NegotiatedReduction,
				2000,
				2100,
				4000,
				3200,
				--5000,
				8000,
				'2000',
				'2100',
				'4000',
				'3200',
				--'5000',
				'8000'
			from #HistoryLines l 
				inner join #HistoryBills b 
					on b.ControlNumber = l.ControlNumber and b.HistoryClientNumber = l.HistoryClientNumber

					Print 'G'
					
--------------INSERTING INTO LZBILLCOMMENT--------------------------
		insert into SAZENPRODLZ.dbo.LZBillComment 
			(LZBatchNumber,LZRecType,LZBillCommentStatus,LZDCN,CommentType,Comment,
			ClientCode,LZReBatchSeq, BillCommentSeq)
		select distinct 
			@BatchNumber as BatchNumber,
			'004' as LZRecType,
			0 as LZBillCommentStatus,
			LZDCN,
			'C' as CommentType,
			(cast(LineSeq as varchar(5)) + ' - ' + ReasonCodes) AS Comment,
			ClientCode,   --- 'DN' is 2 char code
			0 as LZReBatchSeq, 
			2 as BillCommentSeq
		from #TempLine with (nolock) where ReasonCodes <> '' 

		Print 'H'
		
		
Select 3		

			--INSERTING INTO LZBILL from Temp Table
			INSERT INTO SAZENPRODLZ.dbo.LZBill
				(LZBatchNumber,LZRecType,LZBillStatus,ClientCode,ClaimSeq,ClaimSysSubSet,ProviderSeq,
				ProviderSubSet,DOSFirst,CarrierSeqNew,DOSLast,POS,LZPOS,ProvType,LZProvType,ProvSpecialty1,LZProvSpecialty1,ProvZip,ProvState,
				CreateUserID,ModUserID,TotalCharge,TOS,TOB,LZTOS,LZTOB,SubProductCode,RcvdDate,RcvdBRDate,DOI,
				SiteCode,LZSiteCode, LZICDDiagCode1,LZICDDiagCode2,LZICDDiagCode3,LZICDDiagCode4,
				LZICDDiagCode5,LZICDDiagCode6,LZICDDiagCode7,LZICDDiagCode8,					
				TotalAllow,LZClaimNum,LZProvState,LZProvZip,LZDCN,
				LZCarrierSeqNew,LZClientCode,ICDDiagCode1,ICDDiagCode2,ICDDiagCode3,ICDDiagCode4,
				ICDDiagCode5,ICDDiagCode6,ICDDiagCode7,ICDDiagCode8,LZProvTin,PaidDate,PaidAmount,AlreadyRepriced,ReviewDate,
				PostDate,LZTransactionType,AdmitDate, DischargeDate,UB92TOB,LZUB92TOB,ProvBillingNPI,LZProvBillingNPI,ProvFacilityNPI,LZProvFacilityNPI,
				LZProvBillAddr1,
				LZProvBillAddr2,
				LZProvBillCity,
				LZProvBillState,
				LZProvBillZip,
				LZProvPRAddr1,
				LZProvPRAddr2,
				LZProvPRCity,
				LZProvPRState,
				LZProvPRZip,
				LZExternalProviderID,
				DocCtrlID
)
			select
				LZBatchNumber,LZRecType,LZBillStatus,ClientCode,ClaimSeq,ClaimSysSubSet,ProviderSeq,ProviderSubSet,
				DOSFirst,CarrierSeqNew,DOSLast,POS,LZPOS,ProvType,LZProvType,ProvSpecialty1,LZProvSpecialty1,ProvZip,ProvState,CreateUserID,ModUserID,
				TotalCharge,TOS,TOB,LZTOS,LZTOB,
				SubProductCode,RcvdDate,RcvdBRDate,DOI,SiteCode,LZSiteCode,LZICDDiagCode1,LZICDDiagCode2,LZICDDiagCode3,LZICDDiagCode4,
				LZICDDiagCode5,LZICDDiagCode6,LZICDDiagCode7,LZICDDiagCode8,TotalAllow,LZClaimNum,
				LZProvState,LZProvZip,LZDCN,LZCarrierSeqNew,LZClientCode,ICDDiagCode1,ICDDiagCode2,ICDDiagCode3,ICDDiagCode4,ICDDiagCode5,ICDDiagCode6,ICDDiagCode7,ICDDiagCode8,
				LZProvTin,PaidDate,PaidAmount,'Y',
				ReviewDate,PostDate,'A',AdmitDate, DischargeDate,UB92TOB,LZUB92TOB,ProvBillingNPI,LZProvBillingNPI,ProvFacilityNPI,LZProvFacilityNPI,
				LZProvBillAddr1,
				LZProvBillAddr2,
				LZProvBillCity,
				LZProvBillState,
				LZProvBillZip,
				LZProvPRAddr1,
				LZProvPRAddr2,
				LZProvPRCity,
				LZProvPRState,
				LZProvPRZip,
				LZExternalProviderID,
				DocCtrlID
			from #TempBill WITH (NOLOCK)

			Print 'I'
Select 4
		---INSERTING INTO LZLINE from Temp Table
		insert into SAZENPRODLZ.dbo.LZLine 
			(LZBatchNumber,LZRecType,LZLineStatus,ClientCode,LineSeq,DOS,DOSTo,ProcBilled,LZProcBilled,
			ProcCode,LZProcCode,Units,Charge,BRAllow,PPOAllow,POS,Modifier0,LZModifier0,Modifier1,LZModifier1,LZDCN,ProcType,LZProcType,
			ReductionCode1,Reduction1,LZReductionCode1,LZReduction1,
			ReductionCode2,Reduction2,LZReductionCode2,LZReduction2,
			ReductionCode3,Reduction3,LZReductionCode3,LZReduction3,
			ReductionCode4,Reduction4,LZReductionCode4,LZReduction4,
			ReductionCode5,Reduction5,LZReductionCode5,LZReduction5,
			--ReductionCode6,Reduction6,LZReductionCode6,LZReduction6,
			LZTransactionType,Modifier2,LZModifier2,Modifier3,LZModifier3,
			LZLegacyCharge
			--,Modifier4,LZModifier4,Modifier5,LZModifier5, 
			--	Modifier6,LZModifier6,Modifier7,LZModifier7
				)
		select LZBatchNumber,LZRecType,LZLineStatus,ClientCode,LineSeq,DOS,DOSTo,
				Case when RevenueCode <> '' then RevenueCode 
						when NDCCode <> '' then NDCCode 
					else	 ProcBilled end  as ProcBilled,
				Case when RevenueCode <> '' then RevenueCode 
						when NDCCode <> '' then NDCCode 
					else	 ProcBilled end as LZProcBilled,
				Case when RevenueCode <> '' then RevenueCode 
						when NDCCode <> '' then NDCCode 
					else	 ProcBilled end as ProcCode,
				Case when RevenueCode <> '' then RevenueCode 
						when NDCCode <> '' then NDCCode 
						else ProcBilled end as LZProcCode,
				Units,Charge,BRAllow,PPOAllow,POS,Modifier0,LZModifier0,Modifier1,LZModifier1,LZDCN,
				Case when RevenueCode <> '' then 'R' 
					 when NDCCode <> '' then 'N'
				else 'P' end as ProcType,
				Case when RevenueCode <> '' then 'R' 
					 when NDCCode <> '' then 'N'
				else 'P' end as LZProcType ,
				ReductionCode1,Reduction1,LZReductionCode1,LZReduction1,
			ReductionCode2,Reduction2,LZReductionCode2,LZReduction2,
			ReductionCode3,Reduction3,LZReductionCode3,LZReduction3,
			ReductionCode4,Reduction4,LZReductionCode4,LZReduction4,
			ReductionCode5,Reduction5,LZReductionCode5,LZReduction5,
			--ReductionCode6,Reduction6,LZReductionCode6,LZReduction6,
				'A',
				Modifier2,LZModifier2,Modifier3,LZModifier3,Charge
				--,Modifier4,LZModifier4,Modifier5,LZModifier5, 
				--Modifier6,LZModifier6,Modifier7,LZModifier7
		from #TempLine

		Print 'J'
Select 5
		/* Create Temp table to store claim subset specific details for performance */
		Create Table #tempclaims_mtc
		(
			ClaimSysSubSet varchar(10),
			ClaimID varchar(100),
			ClaimSeq bigint,
			DOI datetime
		)


		--Get all the unique ClaimID's to speed up searching
		SET @SqlStr = 'insert into #tempclaims_mtc
		select ClaimSysSubset, ClaimID, ClaimSeq, DOI 
		from ' + @SADatabaseName + '.dbo.claim
		where claimsyssubset = ''' + @ClaimSysSubset + ''''
		
		Exec (@SqlStr)

		Print 'K'

		----- Update ClaimSeq and DOI in LZBill table for the specified Batch Number
		UPDATE lz
		SET ClaimSeq = c.ClaimSeq
			--, DOI = CASE WHEN lz.DOI > 0 THEN lz.DOI ELSE c.DOI END
		--Select lz.clientcode, lz.billseq, lz.claimsyssubset, lz.lzclaimnum, lz.claimseq, c.claimid, c.claimseq
		FROM SAZENPRODLZ.dbo.LZBill lz WITH (nolock)-- (INDEX(IDX_LZBill_1))
			left Join #tempclaims_mtc c
				On lz.ClaimSysSubset = c.ClaimSysSubset and lz.LZClaimNum = c.ClaimID
		WHERE lz.LZBatchNumber = @BatchNumber --AND lz.LZTransactionType = 'A' AND lz.LZBillStatus = 0 AND ISNULL(lz.ClaimSeq, 0) = 0

		------Inserting into LZHeaderTrailer
		insert into SAZENPRODLZ.dbo.LZHeaderTrailer(LZBatchNumber, RecordType, BranchOfficeCode)
		values(@BatchNumber,'FH',@SiteCode)
		--
		insert into SAZENPRODLZ.dbo.LZHeaderTrailer(LZBatchNumber, RecordType, BranchOfficeCode)
		values(@BatchNumber,'FT',@SiteCode)
		--	
		------Inserting into the EDIBatchlog for Rebatching
		SET @SqlStr = 'insert into ' + @SADatabaseName + '.dbo.edibatchlog(BatchNumber,SiteCode,EDIPortType,EDIMapToolID,EDIBatchDate,FileSpec,FileLocation,UserID, FromDate, ToDate,EDIControlSeq,LzRebatchSeq,Preprocess,BatchManagerSeq)
			values(@BatchNumber,''ZZZ'',''I'',''8'',getdate(),''Bill_GAOoperators_PROD'',
		'''',
		''X5'',''01/01/1998'',''12/31/2100'',3,0,0,83)'

		SET @SqlParam = N'@BatchNumber varchar(10)'
							
		Exec dbo.sp_ExecuteSQL @SqlStr, @SqlParam, @BatchNumber

		Print 'L'
	
		Drop Table #HistoryBills
		Drop Table #HistoryLines
		Drop Table #TempBill
		Drop Table #TempLine			
		Drop Table #tempclaims_mtc

		Print 'M'
	
COMMIT TRAN
END TRY
BEGIN CATCH
    print error_message() 
	    ROLLBACK TRAN
END CATCH








--select * from SATSBTEST..BillComment